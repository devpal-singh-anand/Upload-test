# `native/` — Windows-specific primitives

Per [`PROJECT_CONTEXT.md`](../PROJECT_CONTEXT.md) §6.2 (Responsibility boundaries):

> `native/` (Windows-specific) — Platform/runtime-specific implementation requiring
> APIs/SDKs better handled outside Rust. Each native component MUST have exactly one
> Rust-facing interface (in the corresponding `crates/` crate).
>
> **Rule:** No functionality is implemented in both `crates/` and `native/`.

## Subdirectory responsibility map

| `native/` subdirectory | Owns (platform primitives only) | Called BY (`crates/`) |
|---|---|---|
| `isolated-chromium/launcher/` | Chromium runtime launch + arg building | `isolated-chromium` |
| `isolated-chromium/process-control/` | Windows-specific process-tree termination (Job Objects — D-3) | `process-manager` |
| `isolated-chromium/profile/` | Chromium-runtime profile create/teardown primitives | `profile-manager` |
| `isolated-chromium/ipc/` | CDP transport (pipe/port) + native IPC transport (D-2) | `isolated-chromium` |
| `isolated-chromium/capture/` | Chromium-side capture hooks (V-7 — UNVALIDATED) | `capture-manager` |
| `capture/video/` | WGC per-HWND video capture | `capture-manager` |
| `capture/audio/` | Windows audio capture | `capture-manager` |
| `capture/snipping/` | Snipping / OCR / annotation primitives | `capture-manager` |
| `windows/window-control/` | Win32 window management | `windows-integration` |
| `windows/process-control/` | Win32 process primitives (shared with isolated-chromium/process-control) | `process-manager` |
| `windows/media-capture/` | Windows Graphics Capture API primitives | `capture-manager` |

## Phase 1 status

**All subdirectories are DESIGN ONLY.** No code beyond this README.

Subdirectories that are **explicitly gated by deferred items** in
`PROJECT_CONTEXT.md` §14:

| Subdirectory | Gated by |
|---|---|
| `isolated-chromium/launcher/` | D-1 (runtime selection) |
| `isolated-chromium/process-control/` | D-3 (termination mechanism) |
| `isolated-chromium/ipc/` | D-2 (native IPC transport) |
| `isolated-chromium/capture/` | V-7 (Chromium media-capture policy integration) |
| `capture/*` | V-1, V-7 (capture system — Phase 5+) |
| `windows/media-capture/` | V-1, V-7 (Phase 5+) |
