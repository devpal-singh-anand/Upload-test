# Tests

Test directories mirror the project structure.

## Subdirectories

| Path | Purpose |
|------|---------|
| `browser/` | Browser-shell integration tests (Tauri + React) |
| `isolated-chromium/` | Isolated Chromium lifecycle tests (Phase 4+) |
| `capture/` | Capture system tests (Phase 5+) — includes V-1/V-7 test matrix |
| `privacy/` | Privacy engine tests (Phase 6+) |
| `integration/` | Cross-component integration tests |

## Phase 1 status

**DESIGN ONLY.** No tests written yet. Per project rules: "do not write any test
code" until architecture is validated by Windows build/test.

The first test artifacts will be:
1. Windows build verification (manual) — moves `Tauri shell` from DESIGN ONLY to IMPLEMENTED.
2. Browser-shell UI smoke test (manual or scripted) — verifies tab strip, address bar, window controls render.
3. Tauri capability enforcement test — verifies a non-capability command is unreachable from frontend.
