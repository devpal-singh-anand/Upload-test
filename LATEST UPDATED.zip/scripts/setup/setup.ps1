# scripts/setup/setup.ps1
# Phase 1 placeholder — first-time Windows setup script.
#
# This script is DESIGN ONLY. Do NOT run yet. It will be implemented
# when the first Windows build is attempted.
#
# Planned behavior:
#   1. Verify Rust toolchain (rustup) is installed
#   2. Verify Node.js + npm is installed
#   3. Verify MSVC build tools are present
#   4. Verify WebView2 Runtime is installed
#   5. Install workspace dependencies: npm install
#   6. Verify tauri CLI is available: npx tauri --version

Write-Host "Custom Browser — Phase 1 setup script (PLACEHOLDER)"
Write-Host "This script is not yet implemented. See PROJECT_CONTEXT.md for status."
exit 1
