# scripts/

Helper scripts for setup, development, build, and packaging.

## Subdirectories

| Path | Purpose |
|------|---------|
| `setup/` | First-time setup (deps, toolchain check) |
| `development/` | Day-to-day dev helpers (lint, format, run) |
| `build/` | Build helpers (release builds, bundle) |
| `packaging/` | Packaging helpers (msi, nsis) |

## Phase 1 status

**DESIGN ONLY.** Scripts below are placeholders. Real scripts arrive when
the first Windows build is attempted.

## Usage

```powershell
# First-time setup (Windows / PowerShell)
.\scripts\setup\setup.ps1

# Day-to-day development
.\scripts\development\dev.ps1
.\scripts\development\lint.ps1

# Build
.\scripts\build\release.ps1
```
