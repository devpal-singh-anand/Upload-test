//! `browser-core` — top-level orchestration crate.
//!
//! Per PROJECT_CONTEXT.md §6.2:
//!   - `crates/` (Rust) owns application-level orchestration, state, policy, IPC
//!     contracts, lifecycle coordination.
//!   - This crate is the Native Controller's application-facing surface.
//!
//! Phase 1 status: **DESIGN ONLY**. No functional implementation.
//! Phase 2+ will introduce the real Browser Controller trait and orchestration
//! across `browser-state`, `profile-manager`, `workspace-manager`, etc.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

/// Phase marker — every crate exposes this so callers can assert they're
/// talking to the expected project phase.
pub const PROJECT_PHASE: u8 = 1;

/// Phase 1 stub error type. Real errors will be enumerated per crate in Phase 2+.
#[derive(Debug, thiserror::Error)]
pub enum BrowserCoreError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

/// Result type alias for the crate.
pub type Result<T> = std::result::Result<T, BrowserCoreError>;

/// Phase 1 placeholder for the Browser Controller trait.
///
/// Real trait (Phase 2+) will define the orchestration surface used by the
/// Tauri command layer (`apps/browser/src-tauri/src/native_controller.rs`).
pub trait BrowserController: Send + Sync {
    /// Returns the current project phase. Always 1 in Phase 1.
    fn phase(&self) -> u8 {
        PROJECT_PHASE
    }
}

/// Phase 1 stub implementation. Does nothing useful — exists only so the
/// crate compiles and downstream code has a stable symbol to reference.
#[derive(Debug, Default, Clone, Copy)]
pub struct StubController;

impl BrowserController for StubController {}

/// Serializable app descriptor (used by Tauri command layer).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppDescriptor {
    pub name: String,
    pub version: String,
    pub phase: u8,
}

impl AppDescriptor {
    pub fn current() -> Self {
        Self {
            name: env!("CARGO_PKG_NAME").to_string(),
            version: env!("CARGO_PKG_VERSION").to_string(),
            phase: PROJECT_PHASE,
        }
    }
}
