//! `isolated-chromium` — Isolated Chromium launcher + lifecycle.
//!
//! Per PROJECT_CONTEXT.md §7 (Isolated Chromium) + §8 (IPC contract):
//!   - This crate owns the parent-side orchestration of the Isolated Chromium
//!     runtime: launch, CDP connection, tab registry, lifecycle.
//!   - Transport: CDP (`--remote-debugging-pipe` strongly preferred per
//!     ADR-011) + native IPC channel (transport TBD — D-2).
//!   - CDP is NOT the security boundary (ADR-003).
//!
//! Per PROJECT_CONTEXT.md §13 (Phase 1 scope NOT allowed):
//!   - Isolated Chromium runtime selection (D-1) — Phase 4+.
//!   - Final process-tree termination mechanism (D-3) — Phase 4+.
//!
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum IsolatedChromiumError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
    #[error("deferred: D-1 isolated chromium runtime not yet selected")]
    DeferredD1,
    #[error("deferred: D-2 native IPC transport not yet selected")]
    DeferredD2,
}

pub type Result<T> = std::result::Result<T, IsolatedChromiumError>;

/// Isolated Chromium session handle.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IsolatedSession {
    pub session_id: String,
    pub profile_id: String,
    pub cdp_endpoint: CdpEndpoint,
}

/// CDP transport — pipe strongly preferred (ADR-011).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CdpEndpoint {
    /// `--remote-debugging-pipe` — preferred (no TCP exposure).
    Pipe,
    /// `--remote-debugging-port` — LAST-RESORT only (ADR-011).
    Port { host: String, port: u16 },
}
