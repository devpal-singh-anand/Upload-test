//! `profile-manager` — profile lifecycle policy.
//!
//! Per PROJECT_CONTEXT.md §6.2 + ADR-012:
//!   - This crate owns **profile lifecycle policy** (creation, disposal
//!     ordering, session scoping).
//!   - `native/isolated-chromium/profile/` contains ONLY the Chromium-runtime-
//!     specific profile creation/teardown primitives, called BY this crate.
//!
//! Per PROJECT_CONTEXT.md §10.3 (state ownership):
//!   - Parent-owned profiles are persistent.
//!   - Isolated Chromium session profiles are **disposable** and NEVER promoted
//!     to persistent browser profiles.
//!
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum ProfileManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, ProfileManagerError>;

/// Profile kind — distinguishes persistent parent profiles from disposable
/// isolated-session profiles.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum ProfileKind {
    /// Persistent parent-browser profile (PROJECT_CONTEXT.md §10.3).
    Parent,
    /// Disposable isolated-session profile — NEVER promoted to persistent
    /// (PROJECT_CONTEXT.md §10.3).
    IsolatedSession,
}

/// Profile descriptor.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Profile {
    pub id: String,
    pub kind: ProfileKind,
    /// Filesystem path to the profile directory. None for in-memory-only profiles.
    pub path: Option<String>,
}

/// Phase 1 stub trait.
pub trait ProfileManager: Send + Sync {
    /// Create a profile of the given kind. Real implementation (Phase 4+) will
    /// delegate filesystem operations to `native/isolated-chromium/profile/`.
    fn create_profile(&self, kind: ProfileKind) -> Result<Profile>;
}
