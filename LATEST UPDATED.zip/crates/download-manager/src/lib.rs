//! `download-manager` — downloads: persistent record + files.
//!
//! Per PROJECT_CONTEXT.md §10.3 (state ownership):
//!   - Downloads (persistent record + files) live in the **parent** browser.
//!   - Isolated Chromium session downloads are NEVER promoted to persistent
//!     (quarantine + disposal ordering is part of Browser Analysis Mode — Phase 6+).
//!
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum DownloadManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, DownloadManagerError>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadRecord {
    pub id: String,
    pub url: String,
    pub target_path: String,
    pub bytes_received: u64,
    pub bytes_total: Option<u64>,
}
