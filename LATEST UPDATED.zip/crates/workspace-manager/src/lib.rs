//! `workspace-manager` — workspace + tab-group management.
//!
//! Per PROJECT_CONTEXT.md §6.2: `crates/` (Rust) owns application-level
//! state and policy. This crate owns workspace lifecycle + tab grouping policy.
//!
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use browser_state::WorkspaceId;
use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum WorkspaceManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, WorkspaceManagerError>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Workspace {
    pub id: WorkspaceId,
    pub name: String,
}
