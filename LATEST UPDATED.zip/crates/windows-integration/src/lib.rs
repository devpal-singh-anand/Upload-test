//! `windows-integration` — native Windows integration.
//!
//! Per PROJECT_CONTEXT.md §2 (capabilities): Windows Integration
//!   - Native Windows, Window Management, System Tray, OS Integration.
//!
//! Per PROJECT_CONTEXT.md §6.2 boundary:
//!   - This crate is the Rust-facing interface.
//!   - `native/windows/window-control/`, `native/windows/process-control/`,
//!     `native/windows/media-capture/` contain platform primitives called by
//!     this crate.
//!
//! Phase 1 status: **DESIGN ONLY**. Phase 3+ feature.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum WindowsIntegrationError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, WindowsIntegrationError>;

/// Native window handle abstraction (HWND-equivalent).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct NativeWindowHandle(pub u64);
