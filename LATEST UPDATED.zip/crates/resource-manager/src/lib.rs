//! `resource-manager` — CPU/memory awareness, tab suspension, heavy-tab detection.
//!
//! Per PROJECT_CONTEXT.md §2 (capabilities): Resource Management.
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum ResourceManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, ResourceManagerError>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceUsage {
    pub tab_id: String,
    pub cpu_percent: f32,
    pub memory_bytes: u64,
    pub is_suspended: bool,
}
