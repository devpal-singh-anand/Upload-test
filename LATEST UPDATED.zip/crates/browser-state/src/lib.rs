//! `browser-state` — tab/window/workspace state management.
//!
//! Per PROJECT_CONTEXT.md §6.2: `crates/` (Rust) owns application-level state.
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum BrowserStateError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, BrowserStateError>;

/// Tab identity — opaque to callers outside this crate.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct TabId(pub String);

/// Window identity.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct WindowId(pub String);

/// Workspace identity.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct WorkspaceId(pub String);

/// Tab descriptor (Phase 1 stub — real fields land in Phase 2).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tab {
    pub id: TabId,
    pub url: String,
    pub title: String,
    pub window_id: WindowId,
    pub workspace_id: WorkspaceId,
}

/// Phase 1 stub trait. Real trait (Phase 2) will define tab/window/workspace
/// state operations.
pub trait BrowserState: Send + Sync {
    fn list_tabs(&self) -> Vec<Tab>;
}
