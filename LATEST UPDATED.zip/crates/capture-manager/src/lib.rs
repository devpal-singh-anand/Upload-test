//! `capture-manager` — capture policy + session orchestration.
//!
//! Per PROJECT_CONTEXT.md §6.2 + ADR-012:
//!   - This crate owns **capture policy + session orchestration**.
//!   - `native/capture/` and `native/windows/media-capture/` contain ONLY the
//!     platform-specific capture primitives (WGC, audio, snipping), called
//!     BY this crate.
//!
//! Per PROJECT_CONTEXT.md §9.6 + ADR-010 + V-7:
//!   - WGC is the **native capture mechanism**, NOT the enforcement mechanism
//!     for Chromium's `getDisplayMedia()` pipeline.
//!   - V-7 (Chromium media-capture policy integration) is **UNVALIDATED**
//!     and a **Phase-5 capture-system gate**.
//!
//! Phase 1 status: **DESIGN ONLY**. Phase 5+ feature.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum CaptureManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
    #[error("deferred: V-7 chromium media-capture policy integration unvalidated")]
    DeferredV7,
}

pub type Result<T> = std::result::Result<T, CaptureManagerError>;

/// Capture surface kind.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum CaptureSurface {
    /// Per-tab capture (Normal Browser).
    NormalBrowserTab,
    /// Per-window capture (Normal Browser).
    NormalBrowserWindow,
    /// Isolated Chromium window — policy-controlled.
    IsolatedChromiumWindow,
    /// Real Windows Desktop — only when isolated window is minimized (per §9.4).
    RealDesktop,
}

/// Capture modality.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum CaptureModality {
    Video,
    Audio,
    Snipping,
}
