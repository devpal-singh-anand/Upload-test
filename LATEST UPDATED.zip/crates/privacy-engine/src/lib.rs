//! `privacy-engine` — tracker blocking, fingerprinting protection, cookie controls.
//!
//! Per PROJECT_CONTEXT.md §2 (capabilities): Privacy & Security.
//! Phase 1 status: **DESIGN ONLY**. Phase 6+ feature.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum PrivacyEngineError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, PrivacyEngineError>;

/// Privacy rule kind.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum PrivacyRuleKind {
    TrackerBlock,
    FingerprintProtect,
    CookieControl,
    SitePermission,
    RedirectControl,
}
