//! `media-manager` — media playback controls, picture-in-picture, playback speed.
//!
//! Per PROJECT_CONTEXT.md §2 (capabilities): Media.
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum MediaManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, MediaManagerError>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MediaState {
    pub is_playing: bool,
    pub playback_rate: f32,
    pub is_picture_in_picture: bool,
}
