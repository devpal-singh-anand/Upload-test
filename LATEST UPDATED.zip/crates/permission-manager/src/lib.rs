//! `permission-manager` — site permissions + Trusted Command API allowlist.
//!
//! Per PROJECT_CONTEXT.md §10 (trust model) + V-5 (deferred):
//!   - This crate is the future home of the per-command allowlist.
//!   - V-5 enumerates per-command permission rules; per-command enumeration
//!     is deferred to Phase 2+ (lives in `docs/security/trust-model.md`).
//!
//! Phase 1 status: **DESIGN ONLY**.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum PermissionManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
}

pub type Result<T> = std::result::Result<T, PermissionManagerError>;

/// Site permission kinds (PROJECT_CONTEXT.md §2).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum SitePermissionKind {
    Camera,
    Microphone,
    Notifications,
    Geolocation,
    ClipboardRead,
    ClipboardWrite,
    ExternalLaunch,
}

/// Caller class for the Trusted Command API (PROJECT_CONTEXT.md §10.2).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum CallerClass {
    /// Trusted browser UI rendered in Tauri app context.
    BrowserUi,
    /// Lifecycle notifications only (Isolated Chromium → parent).
    ChildProcess,
    /// Web content — NEVER a trusted caller. Listed for completeness.
    WebContent,
}
