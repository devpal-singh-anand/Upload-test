//! `process-manager` — process-tree lifecycle policy.
//!
//! Per PROJECT_CONTEXT.md §6.2 + ADR-012:
//!   - This crate owns **process-tree lifecycle policy**.
//!   - `native/windows/process-control/` contains ONLY the Windows-specific
//!     process-tree termination primitives (Job Objects, etc.), called BY
//!     this crate.
//!
//! Per PROJECT_CONTEXT.md §7.3 + D-3:
//!   - Process tree termination mechanism is **deferred (D-3)**.
//!   - Cleanup ordering matters: process-tree termination confirmation is
//!     required BEFORE profile deletion.
//!
//! Phase 1 status: **DESIGN ONLY**. Phase 4+ feature.

#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, thiserror::Error)]
pub enum ProcessManagerError {
    #[error("not implemented in phase 1: {0}")]
    Phase1Stub(&'static str),
    #[error("deferred: D-3 process-tree termination mechanism not yet selected")]
    DeferredD3,
}

pub type Result<T> = std::result::Result<T, ProcessManagerError>;

/// Process-tree handle (opaque outside this crate).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessTreeHandle {
    pub root_pid: u32,
    pub session_id: String,
}

/// Process-tree termination status.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum TerminationStatus {
    /// Process tree is still running.
    Running,
    /// All processes in the tree have terminated.
    Terminated,
    /// Termination requested but not yet confirmed.
    Terminating,
}
