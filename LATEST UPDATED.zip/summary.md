# Custom Browser — Phase 1 Session Summary (2026-09-27)

Covers everything fixed in this session, an audit of what was hardcoded (and
what still needs to not be), and the recommended next step. Replaces the
prior `summary.md` §8.4 "expected first-build issues" table, which the
project owner had already flagged as unreliable — this document supersedes
it rather than patching it.

---

## 1. Fixes made this session

### F-8 — Trusted Command API allowlist (security, was a potential blocker)

**Symptom:** All six Phase-1 Tauri commands (`get_app_info`, `navigate`,
`get_browser_state`, `create_tab`, `close_tab`, `list_tabs`) were callable
from the frontend via `window.__TAURI_INTERNALS__.invoke()` even though
`capabilities/main.json` granted zero permissions for them. Confirmed live
in DevTools before any fix: all three tested commands resolved with real
data despite no grant.

**Root cause:** Tauri's ACL only auto-generates `allow-<command>` /
`deny-<command>` permissions for **plugin** commands, wired through a
plugin's own `build.rs` `COMMANDS` list. App-own commands — registered
directly in `lib.rs` via `tauri::generate_handler!` — are not auto-covered.
Per Tauri's own docs, the app developer must hand-write a permission file
under `src-tauri/permissions/`. This project had no `permissions/`
directory at all, so nothing gated these six commands.

**Fix:**
- Added `src-tauri/permissions/browser-commands.toml`, declaring
  `allow-browser-shell-commands` with `commands.allow` listing all six
  commands.
- Added `"allow-browser-shell-commands"` to `capabilities/main.json`'s
  permissions array.

**Verification (both directions, Windows-confirmed):**
- With the grant present: `navigate`, `list_tabs`, `get_app_info` all
  resolved normally, including the app's own startup call in `App.tsx`.
- With `"allow-browser-shell-commands"` removed from `main.json` and a full
  rebuild: all three commands **rejected** with
  `"X not allowed. Permissions associated with this command:
  allow-browser-shell-commands"` — including the app's own `get_app_info`
  call, which surfaced as a visible "Failed to load app state" error.
- Grant restored, app confirmed working normally again.

**Status:** Closed. `implementation-status.md` updated accordingly.

---

### F-9 — Browser shell layout (tabs stacking vertically instead of Chrome/Edge-style horizontal row)

**Symptom:** Tab strip, `+` new-tab button, and window controls
(minimize/maximize/close) were rendering as separate stacked rows instead
of one horizontal title-bar row.

**What it was NOT:** The React/Tailwind component structure was correct
throughout — `App.tsx`, `TabStrip.tsx`, and `WindowControls.tsx` all had
the right `flex` / `items-stretch` container structure from the start. No
JSX or Tailwind class changes were needed anywhere.

**Actual root cause — two layered CSP problems:**

1. **`tauri.conf.json`'s `style-src 'self'`** blocked Vite's dev-mode
   hot-reload mechanism, which injects compiled CSS via inline `<style>`
   tags (not a linked `.css` file — that only happens in a production
   build). With styles blocked, all Tailwind classes existed in markup but
   were never actually applied, so plain unstyled `<div>`s stacked
   block-level by default.

2. **A second, independent CSP source**: `index.html` had its own
   hardcoded `<meta http-equiv="Content-Security-Policy">` tag, also with
   `style-src 'self'`, completely out of sync with `tauri.conf.json`. A
   meta-tag CSP and a Tauri-injected CSP are both enforced
   *simultaneously* — the browser satisfies the strictest combination of
   every CSP source present. This meant editing `tauri.conf.json` alone
   (multiple times, multiple approaches) had **no effect**, because the
   meta tag alone was sufficient to keep blocking inline styles regardless
   of what the Tauri config said. This was the actual reason the fix took
   several rounds to land — we were correctly fixing one lock while a
   second, identical lock stayed shut.

**Fix:** Added `'unsafe-inline'` to `style-src` in three places, once the
second lock was found:
- `tauri.conf.json` → `app.security.csp.style-src`
- `tauri.conf.json` → `app.security.devCsp.style-src` (a Tauri-native
  dev-only CSP override field, separate from `csp`)
- `index.html`'s hardcoded meta CSP tag → `style-src`

**Verification:** Windows-confirmed — tab strip, `+` button, and window
controls now render in a single horizontal row; multiple tabs lay out
side-by-side correctly.

**Status:** Closed. `implementation-status.md` updated accordingly.

---

## 2. Hardcoding audit — "nothing must be hardcoded"

This session surfaced one real instance of the exact problem this
principle exists to prevent, plus a few adjacent things worth flagging.

### Found and partially addressed

**CSP defined in two unsynced places.** `tauri.conf.json` and
`index.html`'s meta tag both independently hardcoded the full CSP policy.
Nobody had a rule for which one was authoritative, so they drifted, and
the drift directly caused hours of debugging where fixes to one had zero
visible effect because the other was silently still enforcing the old
policy.

**This is not fully fixed — it's patched.** Both locations now say the
same thing (`'self' 'unsafe-inline'` on `style-src`), but that's two
hardcoded copies of the same policy, still capable of drifting again the
next time either one gets edited alone. **Real fix, not done yet:**
generate `index.html`'s CSP meta tag from `tauri.conf.json` at build time
(a small Vite plugin, or a build-time template substitution step), so
there is exactly one source of truth. Until that exists, any future CSP
change must be applied to both files by hand, and that should be called
out explicitly wherever CSP changes are made.

### Also relaxed as temporary debt (not hardcoding, but flagging alongside it)

`style-src` now includes `'unsafe-inline'` in the **production** `csp`
field too, not only `devCsp` — because `index.html`'s meta tag has no
dev/build split (Vite uses the same file for both), tightening one without
the other would just reintroduce the original bug in dev. This is
acceptable right now only because Phase 1 loads no real content (no
WebView2 page embedding yet). **This must not carry into Phase 3**, when
real web content starts rendering inside the app and `unsafe-inline`
becomes an actual XSS-relevant weakness rather than a dev-convenience
trade-off.

### Other hardcoded values worth a look before Phase 2 (not touched this session, flagging only)

- Repo path drift: docs say `C:\dev\custom-browser`, actual path is
  `D:\DevSpace\MY BROWSER` — already known, listed in the original
  briefing, unresolved.
- Tailwind shell color palette (`shell.bg`, `shell.surface`, etc.) is
  hardcoded in `tailwind.config.js` with no theming/config layer — fine
  for Phase 1 scaffold, but worth deciding now whether theming is ever a
  planned feature, since retrofitting it later is more work than
  designing for it from Phase 2 onward.
- `capabilities/main.json`'s `$schema` path (`../gen/schemas/desktop-schema.json`)
  points at a build-generated file not present in source control — normal
  for Tauri, but worth a one-line comment noting it's expected to 404
  until first build, so it's not mistaken for a broken reference later.

---

## 3. Next step

**Immediate:** Do one full clean re-test pass now that F-8, F-9, and the
CSP fixes are all stacked together, to make sure nothing regressed:

1. `cargo clean -p custom-browser-app` (clears any remaining stale build
   state from this session's back-and-forth)
2. `npm run tauri:dev`
3. Re-run the F-8 command test suite once more (all six commands via
   DevTools) to confirm still-correct allow/deny behavior
4. Visually confirm the horizontal layout with several tabs open
5. Confirm no CSP warnings remain in the console

**If that passes clean: Phase 1 is done.** F-8 and F-9 were the two open
items blocking close-out; everything else on the original list (V-1/V-7
capture pipeline, V-5 trust-model doc, D-1 through D-4 deferred
architecture decisions, isolated Chromium) was already correctly deferred
to later phases and remains untouched.

**Before starting Phase 2:**
- Write `docs/security/trust-model.md` (V-5) — now straightforward, since
  F-8's fix gives you a concrete worked example (the `permissions/`
  pattern for app-own commands) to document as the standard going forward
  for any future commands.
- Decide on the CSP single-source-of-truth fix (see §2) — doesn't have to
  happen before Phase 2 starts, but should happen before Phase 3 (real
  WebView2 content) begins, since that's when the current `unsafe-inline`
  trade-off stops being low-risk.
- Clean, corrected `summary.md` §8.4 replacement — this document.

**Phase 2 scope reminder** (from the original briefing, unchanged): real
tab system, replacing the current stub `TabStub` state in
`native_controller.rs` with actual tab lifecycle management — still gated
appropriately behind Phase 1 closing first.
