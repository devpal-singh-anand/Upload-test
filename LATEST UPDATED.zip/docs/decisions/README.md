# ADR Records

Architecture Decision Records. Each ADR has:

- **Context** — why the decision was needed
- **Decision** — what was decided
- **Consequences** — what follows from the decision

## Authoritative source

The authoritative ADR list is in
[`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §16 (Decision Log).

This directory hosts **expanded** ADRs when a single decision requires more
detail than fits in `PROJECT_CONTEXT.md`. Each ADR gets its own file:

- `adr-001-normal-browser-tauri-webview2.md`
- `adr-002-isolated-chromium-runtime.md`
- `adr-003-cdp-native-ipc.md`
- `adr-004-extensions-mv3-compat.md`
- `adr-005-ua-pins-to-runtime.md`
- `adr-006-capture-wgc-per-window.md`
- `adr-007-mid-stream-source-switch-unvalidated.md`
- `adr-008-disposable-profile.md`
- `adr-009-trust-boundary-layered.md`
- `adr-010-capture-enforcement-not-native.md`
- `adr-011-cdp-pipe-preferred.md`
- `adr-012-crates-native-boundary.md`
- `adr-013-system-chromium-not-production.md`

## Phase 1 status

Per-ADR files are **DESIGN ONLY** — they will be created as their respective
decisions enter implementation. The summary in `PROJECT_CONTEXT.md` §16 is
authoritative.
