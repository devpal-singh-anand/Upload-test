# Implementation Status

Per [`PROJECT_CONTEXT.md`](../PROJECT_CONTEXT.md) §12 (Status Labeling System).

This is the **central status registry**. No per-file status labels — the codebase
is not annotation soup.

## Status labels

| Label | Definition |
|---|---|
| **IMPLEMENTED** | Code exists, builds on Windows, verified against real Chromium/WebView2/Win32. Behavior matches spec. |
| **EXPERIMENTAL** | Code exists, partially verified, known gaps remain. Use with caution. |
| **UNVALIDATED** | Functional implementation exists OR a concrete implementation candidate exists, but it has NOT passed required real-world validation on real Windows/Chromium. Code may exist as a draft but must not be relied on. |
| **BLOCKED** | Validation attempted, returned negative or unknown result. Needs unblock. |
| **DESIGN ONLY** | Intentional spec exists; **NO functional implementation exists**. No code beyond scaffolding or type signatures. |

## Status update rules

- Status transitions require evidence (build log, test result, screenshot).
- Transitions are recorded as a single line in the change log below with date and validator.
- No status may regress silently; regressions are BLOCKED entries with reason.

---

## Current status

| Feature | Status | Notes |
|---|---|---|
| Tauri shell | IMPLEMENTED | Round 2 Windows validation confirmed: `cargo check` finished in 17.60s, `npm run tauri:dev` launches the window, UI renders. Environment: Rust 1.97.1, Tauri 2.12.0, Windows 11 build 26200.9457. Round 3 config changes (`decorations: false`, F-11 root package rename) pending re-validation. |
| Build/test pipeline | IMPLEMENTED | `npm install` → 261 packages; `cargo check` → 17.60s; `npm run tauri:dev` → runtime works. All confirmed on Windows in round 2. |
| 6 Phase-1 commands (stubs) | IMPLEMENTED | All six Tauri commands exercised end-to-end with correct backend logs and correct UI updates. Behavior matches the Phase-1 stub spec (navigate does NOT actually load URLs). |
| Browser UI | UNVALIDATED | Round 3 layout rebuild (F-9) pending re-validation. Previous round 2 layout had doubled window chrome (OS decorations + custom WindowControls). Round 3 fixes this with `decorations: false` and proper horizontal tab strip + nav bar. Awaiting Windows re-validation. |
| Tab management | DESIGN ONLY | Phase 1 stub command surface only. F-7 (monotonic tab ID counter) fixed a stub bug but does not constitute real tab management. Real tab management is Phase 2. |
| Isolated Chromium runtime | DESIGN ONLY | Correcting the v0.1 initial label. Was previously listed as UNVALIDATED, but per PROJECT_CONTEXT.md §12.2 boundary rule: UNVALIDATED means functional implementation exists but is unverified. No implementation exists for Isolated Chromium — only stub type definitions in `crates/isolated-chromium/`. Therefore DESIGN ONLY is correct. Gated by D-1 (Phase 4+). |
| Chromium IPC | DESIGN ONLY | Same correction as above. Only stub type definitions exist in `crates/isolated-chromium/`. Gated by D-1, D-2 (Phase 4+). |
| Video capture | DESIGN ONLY | Phase 5+; gated by V-1, V-7 |
| Audio capture | DESIGN ONLY | Phase 5+ |
| Snipping | DESIGN ONLY | Phase 5+ |
| Privacy engine | DESIGN ONLY | Phase 6+ |
| Process manager | DESIGN ONLY | Gated by D-3 (Phase 4+) |
| Workspaces | DESIGN ONLY | Phase 2+ |
| Downloads | DESIGN ONLY | Phase 2+ |
| DevTools integration | DESIGN ONLY | Phase 7+ |
| Resource manager | DESIGN ONLY | Phase 7+ |
| Windows integration | DESIGN ONLY | Phase 3+ |
| Updates | DESIGN ONLY | Phase 7+ |

### Open reviewer questions (flagged, not resolved — per F-6)

**Q1 (open):** Does a correctly-functioning stub count as IMPLEMENTED under PROJECT_CONTEXT.md §12.2? The definition says "behavior matches spec" — a stub whose spec IS stub behavior technically matches. But calling stubs IMPLEMENTED may undermine the distinction the labels exist to make. Currently: the 6 Phase-1 commands are marked IMPLEMENTED above because their behavior matches the Phase-1 stub spec and was confirmed working on Windows in round 2. Reviewer decision pending.

**Q2 (open):** Does successfully rendering a static shell count as IMPLEMENTED for "Browser UI", or does it require verified interaction with the backend? §12.2 does not cleanly answer this. Currently: Browser UI is marked UNVALIDATED pending round 3 layout re-validation, regardless of how Q2 is resolved. Reviewer decision pending.

## Per-crate status (Rust workspace)

| Crate | Status | Notes |
|---|---|---|
| `browser-core` | DESIGN ONLY | Stub `BrowserController` trait + `AppDescriptor` |
| `browser-state` | DESIGN ONLY | Stub `Tab`/`Window`/`Workspace` types |
| `profile-manager` | DESIGN ONLY | Stub `ProfileManager` trait + `ProfileKind` |
| `workspace-manager` | DESIGN ONLY | Stub `Workspace` type |
| `download-manager` | DESIGN ONLY | Stub `DownloadRecord` type |
| `privacy-engine` | DESIGN ONLY | Stub `PrivacyRuleKind` enum |
| `permission-manager` | DESIGN ONLY | Stub `SitePermissionKind` + `CallerClass` enums |
| `process-manager` | DESIGN ONLY | Stub `ProcessTreeHandle` + `TerminationStatus`; gated by D-3 |
| `isolated-chromium` | DESIGN ONLY | Stub `IsolatedSession` + `CdpEndpoint`; gated by D-1, D-2 |
| `capture-manager` | DESIGN ONLY | Stub `CaptureSurface` + `CaptureModality`; gated by V-1, V-7 |
| `media-manager` | DESIGN ONLY | Stub `MediaState` type |
| `resource-manager` | DESIGN ONLY | Stub `ResourceUsage` type |
| `windows-integration` | DESIGN ONLY | Stub `NativeWindowHandle` type |

## Native component status

| Native path | Status | Gated by |
|---|---|---|
| `native/isolated-chromium/launcher/` | DESIGN ONLY | D-1 |
| `native/isolated-chromium/process-control/` | DESIGN ONLY | D-3 |
| `native/isolated-chromium/profile/` | DESIGN ONLY | D-1 |
| `native/isolated-chromium/ipc/` | DESIGN ONLY | D-1, D-2 |
| `native/isolated-chromium/capture/` | DESIGN ONLY | V-7 |
| `native/capture/video/` | DESIGN ONLY | V-1, V-7 |
| `native/capture/audio/` | DESIGN ONLY | Phase 5+ |
| `native/capture/snipping/` | DESIGN ONLY | Phase 5+ |
| `native/windows/window-control/` | DESIGN ONLY | Phase 3+ |
| `native/windows/process-control/` | DESIGN ONLY | D-3 |
| `native/windows/media-capture/` | DESIGN ONLY | V-1, V-7 |

---

## Change log

| Date | Feature | Transition | Evidence | Validator |
|---|---|---|---|---|
| 2024 | Tauri shell | DESIGN ONLY → UNVALIDATED | First Windows `cargo check` attempt: failed at Tauri build script with `unknown field` error (Z.ai v0.2 schema bug — invalid duplicate window-config field in `tauri.conf.json` `windows[0]`). Environment: Rust 1.97.1, Tauri 2.12.0, Windows 11 build 26200.9457. | Project owner (Windows) |
| 2026-09-27 | Tauri shell config (F-1) | UNVALIDATED → UNVALIDATED (config corrected, awaiting re-validation) | Invalid duplicate window-config field removed from `tauri.conf.json` `windows[0]`; correct Tauri 2.12 `url` field retained. Project owner applied the fix manually on 2026-09-27 to unblock validation (previous Z.ai claim of "FIXED" had not landed in the delivered ZIP). Fix now verified present in `custom-browser-phase1-v0.2.1-npm.zip`. | Z.ai (fix) + Project owner (manual application) |
| 2026-09-27 | Tauri shell config (F-2) | UNVALIDATED → UNVALIDATED (config corrected, awaiting re-validation) | Unauthorized asset-protocol feature removed from `tauri` dependency features in `apps/browser/src-tauri/Cargo.toml` line 19. Did NOT add `assetProtocol` config (would broaden renderer privilege — wrong direction per Phase 1 minimal-surface rule, `PROJECT_CONTEXT.md` §13). Fix verified present in `custom-browser-phase1-v0.2.1-npm.zip`. | Z.ai (fix) |
| 2026-09-27 | Tauri shell | UNVALIDATED → IMPLEMENTED | Round 2 Windows validation succeeded: `cargo check` finished in 17.60s; `npm run tauri:dev` launches window; UI renders; all 6 Phase-1 commands exercised end-to-end with correct backend logs and UI updates. | Project owner (Windows) |
| 2026-09-27 | Build/test pipeline | DESIGN ONLY → IMPLEMENTED | `npm install` → 261 packages; `cargo check` → 17.60s; `npm run tauri:dev` → runtime works. All confirmed on Windows in round 2. | Project owner (Windows) |
| 2026-09-27 | 6 Phase-1 commands (stubs) | DESIGN ONLY → IMPLEMENTED | All six commands (`get_app_info`, `navigate`, `get_browser_state`, `create_tab`, `close_tab`, `list_tabs`) exercised end-to-end. Behavior matches Phase-1 stub spec. | Project owner (Windows) |
| 2026-09-27 | Tab ID generation (F-7) | UNVALIDATED → UNVALIDATED (bug fixed, awaiting re-validation) | Tab ID generation in `native_controller.rs` was non-monotonic (derived from `tabs.len()`), causing collisions after close+create. Replaced with monotonic `next_id: u64` counter. Verified present in `custom-browser-phase1-v0.2.3-npm.zip`. | Z.ai (fix) |
| 2026-09-27 | Browser UI layout (F-9) | UNVALIDATED → UNVALIDATED (layout rebuilt, awaiting re-validation) | `decorations: false` in tauri.conf.json; App.tsx restructured into tab-strip row + nav bar + content + status footer; horizontal tabs; custom window controls at right end of tab strip row. Verified present in `custom-browser-phase1-v0.2.3-npm.zip`. | Z.ai (fix) |
| 2026-09-27 | Frontend invoke centralization (F-10) | UNVALIDATED → UNVALIDATED (centralized, awaiting re-validation) | Created `apps/browser/src/lib/tauri.ts` with one exported function per Tauri command. Updated `App.tsx` to import from `@/lib`. No component imports `invoke()` directly. Verified present in `custom-browser-phase1-v0.2.3-npm.zip`. | Z.ai (fix) |
| 2026-09-27 | Root package.json name (F-11) | UNVALIDATED → UNVALIDATED (renamed, awaiting re-validation) | Root package renamed from "custom-browser" to "custom-browser-workspace" to avoid workspace name collision. Workspace member name unchanged. Verified present in `custom-browser-phase1-v0.2.3-npm.zip`. | Z.ai (fix) |
| _pending_ | Browser UI | UNVALIDATED → IMPLEMENTED | _(awaiting Windows re-validation of F-9 layout rebuild)_ | _owner_ |
| _pending_ | Isolated Chromium runtime | DESIGN ONLY (corrected) | _(was previously listed as UNVALIDATED — corrected per §12.2 boundary rule; only stub types exist, no implementation)_ | _Z.ai (correction)_ |
| _pending_ | Chromium IPC | DESIGN ONLY (corrected) | _(same correction as Isolated Chromium runtime)_ | _Z.ai (correction)_ |
