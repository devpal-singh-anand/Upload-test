# Placeholder — see parent directory README.
# This subdirectory is DESIGN ONLY (per PROJECT_CONTEXT.md).
