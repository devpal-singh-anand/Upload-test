# Security — Threat Model

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §10 + §15.

> **Phase 0 architecture contract is in `PROJECT_CONTEXT.md`.**
>
> This file will be expanded with the detailed threat model in Phase 2+,
> once the per-command allowlist (V-5) begins to take shape.

## Trust boundary summary

The Native Controller is the security boundary. Web content is **NEVER** a
trusted caller, even inside the application's own WebView2 environment.

See [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §10 for the full trust model.
