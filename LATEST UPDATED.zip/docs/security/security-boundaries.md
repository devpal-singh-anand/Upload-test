# Security — Boundaries

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §10 (Security Boundaries & Trust Model).

## Summary

| Boundary | Mechanism |
|---|---|
| Web content → Native Controller | **None.** Web content is never a trusted caller. |
| Browser UI → Native Controller | Tauri 2 Runtime Authority (capabilities + origin check). Capability must explicitly grant command permission. |
| Isolated Chromium → Native Controller | Lifecycle notifications only (no policy authority). |
| Native Controller → Windows/Chromium primitives | Via `crates/` → `native/` boundary (per §6.2). |

## CSP

Per `tauri.conf.json`:
- `default-src 'self'`
- `script-src 'self'` (no unsafe-inline, no unsafe-eval)
- `style-src 'self'`
- `connect-src 'self' ipc: http://ipc.localhost`
- `frame-src 'none'`, `object-src 'none'`

## Phase 1 capabilities

The `main` browser window is granted exactly the permissions listed in
[`apps/browser/src-tauri/capabilities/main.json`](../../apps/browser/src-tauri/capabilities/main.json).
NO `core:default`.

**Status: implemented (Phase 1).** Awaiting Windows build verification.
