# Security — Isolation Model

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §7 + ADR-002 + ADR-008.

The Isolated Chromium is **NOT** a VM. It is a real Chromium process on the same
Windows machine, isolated through controlled profile, lifecycle, permissions,
processes, downloads, capture surfaces, and external launches.

See [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §7 for the full isolation definition.

**Status: DESIGN ONLY.** Detailed isolation model (per-process resource limits,
permission scoping, capture surface restrictions) will be documented here in
Phase 4+.
