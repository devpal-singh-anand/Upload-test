# Architecture — Overview

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §4 (Architecture).

> This is a placeholder. The detailed architecture overview will be written
> in Phase 1+ once the implementation stabilizes.
>
> The authoritative architecture source is
> [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md). This file exists to
> expand on specific architectural details when needed.

## See also

- [`browser-architecture.md`](./browser-architecture.md) — Normal Browser details
- [`isolated-chromium.md`](./isolated-chromium.md) — Isolated Chromium details
- [`capture-architecture.md`](./capture-architecture.md) — Capture system details
- [`windows-integration.md`](./windows-integration.md) — Windows integration details

**Status: DESIGN ONLY**
