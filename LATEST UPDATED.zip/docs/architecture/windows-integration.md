# Architecture — Windows Integration

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §2 (Windows Integration).

> **Phase 3+ feature.** Not yet designed beyond the contract in
> `PROJECT_CONTEXT.md`.
