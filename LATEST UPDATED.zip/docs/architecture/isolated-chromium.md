# Architecture — Isolated Chromium

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §7 + ADR-002.

> **Phase 4+ feature.** Not yet designed beyond the contract in
> `PROJECT_CONTEXT.md`.
>
> Implementation is gated by D-1 (runtime selection) and D-2 (native IPC
> transport) — see `PROJECT_CONTEXT.md` §14.1.
