# Architecture — Normal Browser

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §4 + ADR-001.

The Normal Browser uses **Tauri 2 + WebView2** as its rendering engine.

**Status: DESIGN ONLY.** Detailed architecture (window model, webview
isolation from trusted browser UI, navigation pipeline, multi-window
behavior) will be documented here in Phase 2+.
