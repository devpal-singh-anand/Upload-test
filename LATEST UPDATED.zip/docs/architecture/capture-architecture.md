# Architecture — Capture System

Per [`PROJECT_CONTEXT.md`](../../PROJECT_CONTEXT.md) §9 + ADR-006, ADR-010.

> **Phase 5+ feature.** Not yet designed beyond the contract in
> `PROJECT_CONTEXT.md`.
>
> Critical context: WGC is the **native capture mechanism**, NOT the
> **enforcement mechanism** for Chromium's `getDisplayMedia()` pipeline.
> Enforcement is V-7 — UNVALIDATED.

See also:
- `PROJECT_CONTEXT.md` §9.6 (Native capture vs Chromium getDisplayMedia enforcement)
- `PROJECT_CONTEXT.md` §15.2 (Test matrix for mid-stream source switching)
