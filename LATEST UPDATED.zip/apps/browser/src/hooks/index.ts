/**
 * Shared browser hooks (Phase 1 placeholder).
 *
 * Future hooks: tab management, navigation state, etc.
 * Phase 1 keeps state inline in App.tsx; hooks will be extracted in Phase 2.
 */
export {};
