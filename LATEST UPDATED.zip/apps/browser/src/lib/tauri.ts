/**
 * Frontend Tauri command API layer.
 *
 * Per PROJECT_CONTEXT.md §10.2 (Trust model) + F-10 (frontend invoke
 * centralization): every Tauri command call from the frontend MUST go
 * through this module. No component imports `invoke()` directly.
 *
 * This makes the frontend's callable surface inspectable in one file —
 * the trust boundary described in §10 is auditable here, and will scale
 * when Phase 2+ adds more commands.
 *
 * Each function here wraps a single `invoke()` call. Function names use
 * camelCase (frontend convention); the underlying command names use
 * snake_case (Rust convention). Field names match Rust struct fields
 * exactly (per shared/types/index.ts).
 */
import { invoke } from "@tauri-apps/api/core";
import type { AppInfo, TabStub } from "@shared/types";

/** Returns app metadata (name, version, phase). */
export function getAppInfo(): Promise<AppInfo> {
  return invoke<AppInfo>("get_app_info");
}

/** Phase 1 stub: registers a tab for the URL; does NOT actually navigate. */
export function navigate(url: string): Promise<TabStub> {
  return invoke<TabStub>("navigate", { url });
}

/** Returns the current browser state (Phase 1: tab list only). */
export function getBrowserState(): Promise<TabStub[]> {
  return invoke<TabStub[]>("get_browser_state");
}

/** Creates a new tab with the given URL. */
export function createTab(url: string): Promise<TabStub> {
  return invoke<TabStub>("create_tab", { url });
}

/** Closes the tab with the given ID. Returns true if a tab was removed. */
export function closeTab(id: string): Promise<boolean> {
  return invoke<boolean>("close_tab", { id });
}

/** Lists all open tabs. */
export function listTabs(): Promise<TabStub[]> {
  return invoke<TabStub[]>("list_tabs");
}
