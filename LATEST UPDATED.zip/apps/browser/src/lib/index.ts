/**
 * Frontend-side lib utilities.
 *
 * Barrel file — re-exports the Tauri command API layer.
 * Per F-10: components import Tauri commands from here (or directly
 * from `./tauri`), NOT from `@tauri-apps/api/core` directly.
 */
export * from "./tauri";
