interface StatusBarProps {
  message: string;
  tabCount: number;
}

/**
 * Status bar — single-line footer at the bottom of the window.
 *
 * Per F-9: separate message and tab count with proper spacing — previous
 * implementation concatenated without a separator ("...yet6 tabs").
 */
export function StatusBar({ message, tabCount }: StatusBarProps) {
  return (
    <footer
      className="flex items-center justify-between gap-4 px-3 py-1 bg-shell-surface border-t border-shell-border text-xs text-neutral-500 shrink-0"
      role="contentinfo"
    >
      <span className="truncate flex-1 min-w-0">{message}</span>
      <span className="shrink-0">
        {tabCount} {tabCount === 1 ? "tab" : "tabs"}
      </span>
    </footer>
  );
}
