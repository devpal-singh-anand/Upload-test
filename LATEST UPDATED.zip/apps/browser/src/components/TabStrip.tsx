import type { TabStub } from "@shared/types";

interface TabStripProps {
  tabs: TabStub[];
  activeTabId: string | null;
  onSelect: (id: string) => void;
  onClose: (id: string) => void;
}

/**
 * Tab strip — horizontal row of tabs.
 *
 * Per F-9: tabs are horizontal (not stacked vertically), each ~150–240px
 * wide with uniform height. Active tab is visually distinct.
 * The strip itself does NOT render the new-tab button or window controls —
 * those live in the parent row (App.tsx) per the Chrome/Edge layout.
 */
export function TabStrip({ tabs, activeTabId, onSelect, onClose }: TabStripProps) {
  if (tabs.length === 0) {
    return (
      <div
        className="flex items-stretch h-full min-w-0"
        aria-label="Tabs (empty)"
      />
    );
  }
  return (
    <div
      className="flex items-stretch h-full min-w-0"
      role="tablist"
      aria-label="Browser tabs"
    >
      {tabs.map((tab) => {
        const isActive = tab.id === activeTabId;
        return (
          <div
            key={tab.id}
            className={`group flex items-center gap-2 px-3 min-w-[150px] max-w-[240px] h-full border-r border-shell-border text-sm cursor-pointer select-none shrink-0 transition-colors ${
              isActive
                ? "bg-shell-active text-white border-t-2 border-t-accent"
                : "bg-shell-surface text-neutral-300 hover:bg-shell-hover"
            }`}
            role="tab"
            aria-selected={isActive}
            tabIndex={0}
            onClick={() => onSelect(tab.id)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onSelect(tab.id);
              }
            }}
          >
            <span className="truncate flex-1">{tab.title || tab.url}</span>
            <button
              className="shrink-0 w-5 h-5 flex items-center justify-center rounded text-neutral-500 hover:text-white hover:bg-shell-hover text-xs opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label={`Close tab ${tab.title}`}
              onClick={(e) => {
                e.stopPropagation();
                onClose(tab.id);
              }}
              type="button"
            >
              ×
            </button>
          </div>
        );
      })}
    </div>
  );
}
