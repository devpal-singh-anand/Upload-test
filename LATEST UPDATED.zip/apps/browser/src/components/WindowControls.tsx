import { useEffect, useState } from "react";
import { getCurrentWindow } from "@tauri-apps/api/window";

/**
 * Custom window controls — Phase 1.
 *
 * Per F-9: with `decorations: false` in tauri.conf.json, the OS title bar
 * is gone. This component IS the only window chrome. Sits at the right end
 * of the tab-strip row (Row 1 in App.tsx).
 *
 * Uses Tauri 2 window API directly. Per capabilities/main.json, only:
 *   - core:window:allow-minimize
 *   - core:window:allow-toggle-maximize
 *   - core:window:allow-close
 *   - core:window:allow-start-dragging
 * are granted. No other window operations.
 *
 * Buttons stop propagation on mousedown so the parent's
 * `data-tauri-drag-region` doesn't start a window drag when a control
 * is clicked.
 */
export function WindowControls() {
  const [win, setWin] = useState<ReturnType<typeof getCurrentWindow> | null>(null);

  useEffect(() => {
    setWin(getCurrentWindow());
  }, []);

  const stop = (e: React.MouseEvent) => e.stopPropagation();
  const handleMinimize = () => win?.minimize();
  const handleToggleMax = () => win?.toggleMaximize();
  const handleClose = () => win?.close();

  return (
    <div
      className="flex items-stretch shrink-0"
      role="group"
      aria-label="Window controls"
    >
      <button
        className="w-11 h-9 flex items-center justify-center text-neutral-400 hover:bg-shell-hover hover:text-white transition-colors"
        onClick={handleMinimize}
        onMouseDown={stop}
        title="Minimize"
        aria-label="Minimize"
        disabled={!win}
        type="button"
      >
        –
      </button>
      <button
        className="w-11 h-9 flex items-center justify-center text-neutral-400 hover:bg-shell-hover hover:text-white transition-colors"
        onClick={handleToggleMax}
        onMouseDown={stop}
        title="Maximize / Restore"
        aria-label="Maximize or restore"
        disabled={!win}
        type="button"
      >
        ▢
      </button>
      <button
        className="w-11 h-9 flex items-center justify-center text-neutral-400 hover:bg-red-600 hover:text-white transition-colors"
        onClick={handleClose}
        onMouseDown={stop}
        title="Close"
        aria-label="Close window"
        disabled={!win}
        type="button"
      >
        ×
      </button>
    </div>
  );
}
