import { useState, type FormEvent } from "react";

interface AddressBarProps {
  onSubmit: (url: string) => void;
  disabled: boolean;
}

/**
 * Address bar — Phase 1.
 *
 * Per F-9 layout: nav bar is a horizontal row with
 *   - left: back / forward / reload / home buttons
 *   - middle: address bar (flex-grow)
 *   - right: star / menu placeholder buttons
 *
 * Back/forward/reload/home are disabled in Phase 1 (no real navigation).
 * Star/menu are visual placeholders only.
 */
export function AddressBar({ onSubmit, disabled }: AddressBarProps) {
  const [url, setUrl] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = url.trim();
    if (trimmed.length === 0) return;
    // Phase 1: no URL normalization (real navigation is Phase 2+).
    onSubmit(trimmed);
    setUrl("");
  };

  return (
    <form
      className="flex items-center gap-1 px-2 h-10 bg-shell-surface border-b border-shell-border"
      onSubmit={handleSubmit}
    >
      {/* Left: navigation buttons (disabled in Phase 1) */}
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Back (not yet implemented)"
        aria-label="Back"
      >
        ←
      </button>
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Forward (not yet implemented)"
        aria-label="Forward"
      >
        →
      </button>
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Reload (not yet implemented)"
        aria-label="Reload"
      >
        ⟳
      </button>
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Home (not yet implemented)"
        aria-label="Home"
      >
        ⌂
      </button>

      {/* Middle: address bar (flex-grow, fills available width) */}
      <input
        className="flex-1 min-w-0 bg-shell-bg border border-shell-border rounded-full px-4 py-1.5 text-sm text-neutral-200 placeholder:text-neutral-500 focus:outline-none focus:border-accent"
        type="text"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder="Search or enter address"
        disabled={disabled}
        aria-label="Address bar"
        autoFocus
      />

      {/* Right: star / menu placeholders (Phase 1: visual only, no handlers) */}
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Bookmark (not yet implemented)"
        aria-label="Bookmark"
      >
        ☆
      </button>
      <button
        type="button"
        className="nav-btn"
        disabled
        title="Menu (not yet implemented)"
        aria-label="Menu"
      >
        ⋮
      </button>

      {/* Go button — kept for explicit submit; Enter key also submits */}
      <button
        type="submit"
        className="ml-1 px-3 py-1.5 text-sm rounded bg-accent text-white hover:bg-accent-hover transition-colors disabled:opacity-50"
        disabled={disabled}
      >
        Go
      </button>
    </form>
  );
}
