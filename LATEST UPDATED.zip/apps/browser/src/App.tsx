/**
 * Browser shell — Phase 1 scaffold (Round 3 layout).
 *
 * Per PROJECT_CONTEXT.md §13 Phase 1 scope (allowed):
 *   "browser-shell scaffolding (tab strip, address bar, window controls — UI only)"
 *
 * Layout (F-9 rebuild): matches Chrome / Edge / Opera / Brave / Vivaldi
 * structure — horizontal tab strip + custom window controls in the same
 * top row (decorations:false in tauri.conf.json), nav bar below, content
 * area fills remaining space, single-line status footer.
 *
 * This is UI ONLY. Real navigation, real tabs, real webview rendering
 * come in Phase 2 (tab system) and Phase 3 (Windows integration / WebView2).
 *
 * Per F-10: all Tauri command calls go through `@/lib` — no direct
 * `invoke()` imports in this file.
 */
import { useEffect, useState, useCallback } from "react";
import type { AppInfo, TabStub } from "@shared/types";
import { getAppInfo, createTab, closeTab, listTabs, navigate } from "@/lib";
import { TabStrip } from "./components/TabStrip";
import { AddressBar } from "./components/AddressBar";
import { WindowControls } from "./components/WindowControls";
import { StatusBar } from "./components/StatusBar";

export default function App() {
  const [appInfo, setAppInfo] = useState<AppInfo | null>(null);
  const [tabs, setTabs] = useState<TabStub[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>(
    "Phase 1 scaffold — no actual navigation yet"
  );

  // Load app info + initial tab state on mount.
  useEffect(() => {
    (async () => {
      try {
        const [info, currentTabs] = await Promise.all([
          getAppInfo(),
          listTabs(),
        ]);
        setAppInfo(info);
        setTabs(currentTabs);
        if (currentTabs.length > 0) {
          setActiveTabId(currentTabs[0].id);
        }
      } catch (err) {
        console.error("Failed to load app state:", err);
        setStatusMessage(`Error: ${String(err)}`);
      }
    })();
  }, []);

  const handleNavigate = useCallback(async (url: string) => {
    try {
      const newTab = await navigate(url);
      setTabs((prev) => [...prev, newTab]);
      setActiveTabId(newTab.id);
      setStatusMessage(`Created tab for: ${url}`);
    } catch (err) {
      setStatusMessage(`Navigate error: ${String(err)}`);
    }
  }, []);

  const handleNewTab = useCallback(async () => {
    try {
      const tab = await createTab("about:blank");
      setTabs((prev) => [...prev, tab]);
      setActiveTabId(tab.id);
      setStatusMessage("New tab created");
    } catch (err) {
      setStatusMessage(`Create tab error: ${String(err)}`);
    }
  }, []);

  const handleCloseTab = useCallback(async (id: string) => {
    try {
      const removed = await closeTab(id);
      if (removed) {
        setTabs((prev) => {
          const next = prev.filter((t) => t.id !== id);
          if (activeTabId === id) {
            setActiveTabId(next.length > 0 ? next[0].id : null);
          }
          return next;
        });
        setStatusMessage(`Closed tab ${id}`);
      }
    } catch (err) {
      setStatusMessage(`Close tab error: ${String(err)}`);
    }
  }, [activeTabId]);

  return (
    <div className="flex flex-col h-screen bg-shell-bg overflow-hidden">
      {/* Row 1: tab strip + new-tab button + custom window controls.
          This row IS the window's title bar (decorations:false in tauri.conf.json).
          WindowControls handles window dragging via start-dragging capability. */}
      <div
        className="flex items-stretch h-9 bg-shell-surface border-b border-shell-border"
        data-tauri-drag-region
      >
        {/* Tab strip — horizontal, fills available width before controls */}
        <div className="flex-1 flex items-stretch overflow-x-auto min-w-0">
          <TabStrip
            tabs={tabs}
            activeTabId={activeTabId}
            onSelect={setActiveTabId}
            onClose={handleCloseTab}
          />
          {/* New-tab button — at end of tab strip, before window controls */}
          <button
            className="flex items-center justify-center w-9 h-9 text-neutral-400 hover:bg-shell-hover hover:text-white transition-colors shrink-0"
            onClick={handleNewTab}
            title="New tab"
            aria-label="New tab"
            type="button"
          >
            +
          </button>
        </div>
        {/* Custom window controls — right end of title bar row */}
        <WindowControls />
      </div>

      {/* Row 2: nav bar — back/forward/reload/home on left, address bar middle, star/menu on right */}
      <AddressBar onSubmit={handleNavigate} disabled={false} />

      {/* Row 3: content area — fills remaining vertical space */}
      <main className="flex-1 flex items-center justify-center bg-shell-bg text-neutral-500 text-sm overflow-auto">
        <div className="text-center px-4">
          <p className="mb-1 text-neutral-400">Custom Browser — Phase 1</p>
          <p className="text-xs">WebView2 surface arrives in Phase 3</p>
          {appInfo && (
            <p className="mt-3 text-xs text-neutral-600">
              {appInfo.name} v{appInfo.version} · Phase {appInfo.phase}
            </p>
          )}
        </div>
      </main>

      {/* Row 4: single-line status footer */}
      <StatusBar message={statusMessage} tabCount={tabs.length} />
    </div>
  );
}
