/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // Browser shell palette — neutral, no indigo/blue (per project styling rules)
        shell: {
          bg: "#1a1a1a",
          surface: "#242424",
          border: "#333333",
          hover: "#2e2e2e",
          active: "#3a3a3a",
        },
        accent: {
          DEFAULT: "#d97706", // amber-600
          hover: "#b45309",
        },
      },
    },
  },
  plugins: [],
};
