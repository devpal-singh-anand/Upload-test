//! Tauri command registration — the bridge from React/TS frontend to the
//! Rust privileged layer.
//!
//! Per PROJECT_CONTEXT.md §10 + ChatGPT Phase-1 rules:
//!
//!   1. A Tauri command being callable from the browser UI is NOT sufficient
//!      authorization. Capability + permission must be explicitly granted
//!      in `capabilities/main.json`.
//!   2. Each command here MUST have its corresponding permission in
//!      `capabilities/main.json`. Commands without a granted permission
//!      are unreachable from the frontend.
//!   3. These commands are deliberately minimal — Phase 1 browser shell only.
//!      No commands exist for: isolated Chromium launch, capture, extensions,
//!      process-tree control, or any Phase 4+ feature.

use crate::native_controller::{NativeController, TabStub};

#[derive(Debug, serde::Serialize)]
pub struct AppInfo {
    pub name: String,
    pub version: String,
    pub phase: u8,
}

/// Returns basic app metadata. Used by frontend to display version info.
#[tauri::command]
pub async fn get_app_info() -> AppInfo {
    AppInfo {
        name: env!("CARGO_PKG_NAME").to_string(),
        version: env!("CARGO_PKG_VERSION").to_string(),
        phase: 1,
    }
}

/// Phase 1 navigation stub.
///
/// NOTE: This does NOT actually load the URL in a real browser surface.
/// Phase 1 only scaffolds the command surface. Real navigation requires
/// the tab/webview system (Phase 2) and the WebView2 integration (Phase 3).
///
/// Per PROJECT_CONTEXT.md §13 Phase 1 scope (allowed):
///   "browser-shell scaffolding (tab strip, address bar, window controls — UI only)"
///
/// This command updates internal tab state only; no navigation occurs.
#[tauri::command]
pub async fn navigate(
    url: String,
    state: tauri::State<'_, NativeController>,
) -> Result<TabStub, String> {
    if url.trim().is_empty() {
        return Err("URL must not be empty".to_string());
    }
    // Phase 1: just create/update tab state. No actual navigation.
    Ok(state.create_tab(url).await)
}

/// Returns the current browser state — Phase 1 just exposes tab list.
#[tauri::command]
pub async fn get_browser_state(
    state: tauri::State<'_, NativeController>,
) -> Result<Vec<TabStub>, String> {
    Ok(state.list_tabs().await)
}

/// Creates a new tab. Phase 1: tab is registered in NativeController state.
#[tauri::command]
pub async fn create_tab(
    url: String,
    state: tauri::State<'_, NativeController>,
) -> Result<TabStub, String> {
    Ok(state.create_tab(url).await)
}

/// Closes a tab by ID.
#[tauri::command]
pub async fn close_tab(
    id: String,
    state: tauri::State<'_, NativeController>,
) -> Result<bool, String> {
    Ok(state.close_tab(&id).await)
}

/// Lists all open tabs.
#[tauri::command]
pub async fn list_tabs(
    state: tauri::State<'_, NativeController>,
) -> Result<Vec<TabStub>, String> {
    Ok(state.list_tabs().await)
}
