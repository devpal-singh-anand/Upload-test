//! Custom Browser — Tauri 2 desktop app entry point.
//!
//! Phase 1: thin shell. Real browser logic lives in workspace crates
//! (see PROJECT_CONTEXT.md §6 repository structure).
//!
//! Per PROJECT_CONTEXT.md §10 + ChatGPT Phase-1 rules:
//!   - A Tauri command being callable from the browser UI is NOT sufficient
//!     authorization.
//!   - Capabilities and command permissions MUST be defined explicitly.
//!   - Browser UI's privileged surface MUST be minimal.
//!   - Navigated web content MUST NOT inherit browser UI capabilities.
//!
//! See `capabilities/main.json` for the explicit capability granted to the
//! `main` window. Commands below are registered, but the browser UI may
//! only invoke those whose permission is granted in `capabilities/main.json`.

// Prevent additional console window on Windows in release.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    custom_browser_app_lib::run()
}
