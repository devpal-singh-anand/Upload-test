//! Custom Browser — Tauri 2 lib entry.
//!
//! This is the **privileged layer** (Rust-side command router) per
//! PROJECT_CONTEXT.md §10.1. It is the ONLY component that may invoke
//! the Native Controller (see `browser-core` crate).
//!
//! Trust model:
//!   - Tauri Runtime Authority validates the invoking webview's origin/capabilities
//!     BEFORE a command reaches this layer.
//!   - This layer is reached ONLY via Tauri IPC, in-process. No network exposure.
//!   - "React frontend" = trusted browser UI rendered in the Tauri app context,
//!     NOT arbitrary React-rendered web content (PROJECT_CONTEXT.md §10.2).
//!
//! See `capabilities/main.json` for the explicit capability granted to the
//! `main` window. NO `core:default` is used.

use tracing_subscriber::{fmt, prelude::*, EnvFilter};

mod commands;
mod native_controller;

/// Entry point invoked by `main.rs`.
pub fn run() {
    init_tracing();

    tracing::info!(
        version = env!("CARGO_PKG_VERSION"),
        "Custom Browser starting (Phase 1 scaffold)"
    );

    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .manage(native_controller::NativeController::new())
        .invoke_handler(tauri::generate_handler![
            // ── Browser shell commands (Phase 1) ─────────────────────────────────
            // Capability: browser-ui-main (see capabilities/main.json)
            // NOTE: Each command here is callable from the browser UI ONLY because
            // the capability explicitly grants its permission. Removing a command
            // from this list is safe; adding one requires updating capabilities.
            commands::get_app_info,
            commands::navigate,
            commands::get_browser_state,
            commands::create_tab,
            commands::close_tab,
            commands::list_tabs,
        ])
        .setup(|_app| {
            tracing::info!("Tauri app initialized");
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running Custom Browser");
}

fn init_tracing() {
    let env_filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("info,custom_browser_app_lib=debug"));

    tracing_subscriber::registry()
        .with(env_filter)
        .with(fmt::layer().with_target(true).with_file(false).with_line_number(true))
        .init();
}
