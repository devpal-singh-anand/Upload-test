//! Native Controller — the security boundary (PROJECT_CONTEXT.md §10).
//!
//! Phase 1 stub. Real implementation will live in `browser-core` crate and
//! the various `crates/*` siblings. This stub exists so the Tauri command
//! layer has a stable single point of contact with the privileged surface.
//!
//! Per PROJECT_CONTEXT.md §6.2 boundary rule:
//!   - `crates/` (Rust) owns application-level orchestration, state, policy.
//!   - `native/` (Windows-specific) owns platform primitives.
//!   - This controller is the Rust-facing interface for both.

use std::sync::Arc;
use tokio::sync::Mutex;

/// Phase-1 placeholder for the Native Controller.
///
/// Real implementation (Phase 2+) will delegate to:
///   - `browser-core` (orchestration)
///   - `browser-state` (tab/window/workspace state)
///   - `process-manager` (isolated Chromium lifecycle — Phase 4+)
///   - `capture-manager` (capture policy — Phase 5+)
///   - `permission-manager` (site permissions)
pub struct NativeController {
    inner: Arc<Mutex<NativeControllerState>>,
}

/// Phase-1 controller state.
///
/// `next_id` is a monotonic counter that NEVER decreases, even when tabs
/// are closed. This prevents ID collisions after close+create cycles
/// (F-7 fix). The previous implementation derived IDs from
/// `tabs.len() + 1`, which collided when a tab was closed and a new
/// one created (e.g., create tab-1/2/3, close tab-2, create new tab
/// → would re-generate "tab-3" and collide).
struct NativeControllerState {
    /// Monotonic counter for tab IDs. Starts at 1. Increments on each
    /// `create_tab` call. Never resets, never decreases.
    next_id: u64,
    /// Phase 1 placeholder — tab list is owned here for scaffold purposes.
    /// Real tab state moves to `browser-state` crate.
    tabs: Vec<TabStub>,
}

impl Default for NativeControllerState {
    fn default() -> Self {
        Self {
            next_id: 1,
            tabs: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct TabStub {
    pub id: String,
    pub url: String,
    pub title: String,
}

impl NativeController {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(NativeControllerState::default())),
        }
    }

    pub async fn create_tab(&self, url: String) -> TabStub {
        let mut state = self.inner.lock().await;
        // F-7: monotonic counter — never derives from tabs.len(). ID is
        // unique for the lifetime of the controller, never reused even
        // after close_tab.
        let id_num = state.next_id;
        state.next_id = state.next_id.checked_add(1).expect("tab id counter overflowed");
        let id = format!("tab-{}", id_num);
        let title = format!("Tab {}", id_num);
        let tab = TabStub { id, url, title };
        state.tabs.push(tab.clone());
        tracing::info!(tab_id = %tab.id, url = %tab.url, "Created tab");
        tab
    }

    pub async fn close_tab(&self, id: &str) -> bool {
        let mut state = self.inner.lock().await;
        let before = state.tabs.len();
        state.tabs.retain(|t| t.id != id);
        let removed = state.tabs.len() < before;
        if removed {
            tracing::info!(tab_id = %id, "Closed tab");
        }
        // NOTE: state.next_id is intentionally NOT decremented here.
        // Monotonic means monotonic — closed tab IDs are never reused.
        removed
    }

    pub async fn list_tabs(&self) -> Vec<TabStub> {
        self.inner.lock().await.tabs.clone()
    }
}

impl Default for NativeController {
    fn default() -> Self {
        Self::new()
    }
}
