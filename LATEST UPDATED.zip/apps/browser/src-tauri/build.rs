fn main() {
    // tauri-build reads tauri.conf.json and emits build artifacts.
    // Capabilities are loaded from `capabilities/*.json` automatically.
    tauri_build::build()
}
