/**
 * Tauri command protocol definitions — keep in sync with
 * `apps/browser/src-tauri/src/commands.rs`.
 *
 * Per PROJECT_CONTEXT.md §10 + ChatGPT Phase-1 rules:
 *   - Each command here MUST have its corresponding permission in
 *     `apps/browser/src-tauri/capabilities/main.json`.
 *   - A command being callable from the browser UI is NOT sufficient
 *     authorization. Capability + permission must be explicitly granted.
 *
 * Phase 1 commands — minimal browser shell surface only.
 */
import type { AppInfo, TabStub } from "../types";

export interface BrowserCommands {
  /** Returns app metadata. */
  get_app_info(): Promise<AppInfo>;

  /**
   * Phase 1 navigation stub. Updates internal tab state only — does NOT
   * actually load the URL (real navigation is Phase 2+).
   */
  navigate(url: string): Promise<TabStub>;

  /** Returns current browser state (Phase 1: tab list only). */
  get_browser_state(): Promise<TabStub[]>;

  /** Creates a new tab. */
  create_tab(url: string): Promise<TabStub>;

  /** Closes a tab by ID. */
  close_tab(id: string): Promise<boolean>;

  /** Lists all open tabs. */
  list_tabs(): Promise<TabStub[]>;
}
