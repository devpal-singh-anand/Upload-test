/**
 * Shared constants — keep in sync with Rust constants where applicable.
 */

/** Project version — matches `Cargo.toml` workspace version. */
export const APP_VERSION = "0.1.0" as const;

/** Current project phase. */
export const PROJECT_PHASE = 1 as const;

/** Default tab URL when none specified. */
export const DEFAULT_TAB_URL = "about:blank" as const;

/** Tauri window labels — must match `tauri.conf.json` window labels. */
export const WINDOW_LABELS = {
  main: "main",
} as const;

/** CSP source allowlist — kept in sync with `tauri.conf.json` security.csp. */
export const CSP_SOURCES = {
  defaultSrc: "'self'",
  imgSrc: "'self' data: blob:",
  scriptSrc: "'self'",
  styleSrc: "'self'",
  connectSrc: "'self' ipc: http://ipc.localhost",
  fontSrc: "'self' data:",
} as const;
