/**
 * Shared types — used by frontend (apps/browser/src) AND mirrored in Rust
 * (apps/browser/src-tauri/src). Keep field names + shapes in sync.
 *
 * Per PROJECT_CONTEXT.md §6 (repository structure):
 *   shared/types/  ← shared TypeScript types
 */

/** App descriptor returned by `get_app_info` Tauri command. */
export interface AppInfo {
  name: string;
  version: string;
  phase: number;
}

/** Tab stub — Phase 1 representation. Phase 2 will expand this. */
export interface TabStub {
  id: string;
  url: string;
  title: string;
}

/** Project phase constants — keep in sync with Rust `browser-core::PROJECT_PHASE`. */
export const PROJECT_PHASE = 1 as const;
