# `shared/`

TypeScript definitions shared between frontend (`apps/browser/src`) and the
TypeScript-side of the Tauri command surface.

## Subdirectories

| Path | Purpose |
|------|---------|
| `types/` | Shared TypeScript interfaces (mirrors Rust types where applicable) |
| `protocols/` | Tauri command protocol definitions (mirrors `commands.rs`) |
| `constants/` | Shared constants (mirrors Rust constants where applicable) |

## Rule

**Frontend code must NOT import from `apps/browser/src-tauri/` directly.**
All Tauri-boundary types flow through `shared/`.

Rust-side: keep field names + shapes in sync manually. A future Phase 2 task
will consider `ts-rs` or `specta` for automatic type generation.
